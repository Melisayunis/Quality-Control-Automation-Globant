/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import entidad.producto;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Mafe
 */
public class ServicioProducto {

    Scanner read = new Scanner(System.in);

    public producto CrearProducto() {
        producto p = new producto();

        System.out.println("Nombre del producto");
        p.setNombre(read.next());
        System.out.println("Precio del producto");
        p.setPrecio(read.nextInt());
        System.out.println("id del producto");
        p.setID(read.nextInt());

        return p;
    }

    public void MostrarProductos(producto p) {
        System.out.println(p.toString());
    }

    public void ModificarProducto(producto p) {

        System.out.println("Nombre del producto");
        p.setNombre(read.next());
        System.out.println("Precio del producto");
        p.setPrecio(read.nextInt());
        System.out.println("id del producto");
        p.setID(read.nextInt());

    }

    public void EliminarProducto(ArrayList<producto> p, int id) {

        for (int i = 0; i < p.size(); i++) {
            if (p.get(i).getID() == id) {
                System.out.println("EL producto "+p.get(i).toString()+" fue eliminado");
                p.remove(i);
            }

        }

    }
}
