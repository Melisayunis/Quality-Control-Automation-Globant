/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import entidad.producto;
import entidad.tienda;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Mafe
 */
public class ServicioTienda {

    Scanner read = new Scanner(System.in);
    ArrayList<tienda> TL = new ArrayList();
    ServicioProducto SP = new ServicioProducto();

    public tienda CrearTienda() {

        tienda t = new tienda();
        System.out.println("domicilio de la tienda");
        t.setDomicilio(read.next());
        System.out.println("representante de la tienda");
        t.setRepresentante(read.next());
        System.out.println("id de la tienda");
        t.setID(read.nextInt());
        TL.add(t);

        return t;
    }

    public void MostrarTiendas() {
        for (tienda obj : TL) {
            System.out.println(obj.toString());
        }
    }

    public void ModificarTiendas(int id) {

        for (int i = 0; i < TL.size(); i++) {
            if (TL.get(i).getID() == id) {
                System.out.println("domicilio de la tienda");
                TL.get(i).setDomicilio(read.next());
                System.out.println("representante de la tienda");
                TL.get(i).setRepresentante(read.next());
                System.out.println("id de la tienda");
                TL.get(i).setID(read.nextInt());
            }

        }

    }

    public void EliminarTiendas(int id) {

        for (int i = 0; i < TL.size(); i++) {
            if (TL.get(i).getID() == id) {
                TL.remove(i);
            }

        }

    }

    public void AgregarProductos(int TiendaID) {

        for (int i = 0; i < TL.size(); i++) {
            if (TL.get(i).getID() == TiendaID) {
                System.out.println("Stock inicial");
                int cant = read.nextInt();
                TL.get(i).getProducto().put(SP.CrearProducto(), cant);
            }

        }

//        System.out.println("Id del producto");
//        int ids = read.nextInt();
//        System.out.println("stock del producto");
//        int num = read.nextInt();
//        PL.put(ids, num);
    }

    public void venderProductos(int id, int TiendaID) {

        for (int i = 0; i < TL.size(); i++) {
            if (TL.get(i).getID() == TiendaID) {
                for (Map.Entry<producto, Integer> entry : TL.get(i).getProducto().entrySet()) {

                    if (entry.getKey().equals(id)) {
                        System.out.println("Cuantos productos vendiste");
                        int cant = read.nextInt();
                        entry.setValue(entry.getValue() - cant);
                    }

                }
            }

        }

    }

    public void eliminarProductos(int id, int TiendaID) {

        for (int i = 0; i < TL.size(); i++) {
            if (TL.get(i).getID() == TiendaID) {
                for (Map.Entry<producto, Integer> entry : TL.get(i).getProducto().entrySet()) {

                    if (entry.getKey().equals(id)) {

                        TL.get(i).getProducto().remove(entry.getKey());

                    }

                }
            }

        }

    }

    public void verStock(int id, int TiendaID) {
        for (int i = 0; i < TL.size(); i++) {
            if (TL.get(i).getID() == TiendaID) {
                for (Map.Entry<producto, Integer> entry : TL.get(i).getProducto().entrySet()) {

                        System.out.println(entry.getKey());
                     System.out.println(entry.getValue());

                }
            }

        }

    }

}
