/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.ejergrupalrelaciones;

import entidad.tienda;
import java.util.Scanner;
import servicio.ServicioTienda;

/**
 *
 * @author Mafe
 */
public class EjerGrupalRelaciones {

    Scanner read = new Scanner(System.in);

    public static void main(String[] args) {

        tienda tienda = new tienda();
        ServicioTienda ST = new ServicioTienda();
        Scanner scanner = new Scanner(System.in).useDelimiter("\n");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Crear Producto");
            System.out.println("2. Mostrar Productos");
            System.out.println("3. Modificar Producto");
            System.out.println("4. Eliminar Producto");
            System.out.println("5. Salir");
            System.out.print("Elija una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:

                case 2:
                    ST.eliminarProductos(opcion, opcion);
                    break;
                case 3:

                case 4:
                    System.out.print("ID del Producto a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    tienda.eliminarProductos(idEliminar);
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    System.exit(0);
                default:
                    System.out.println("Opción no valida. Elija otra opcion.");
                    break;
            }
        }
    }
