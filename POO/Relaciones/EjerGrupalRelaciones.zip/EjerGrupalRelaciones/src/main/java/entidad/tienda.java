/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Mafe
 */
public class tienda {
    
    private int ID;
    private HashMap<producto,Integer> producto;
    private String domicilio;
    private String representante;

    public tienda(int ID, HashMap<producto, Integer> producto, String domicilio, String representante) {
        this.ID = ID;
        this.producto = producto;
        this.domicilio = domicilio;
        this.representante = representante;
    }

    public tienda() {
    }

    @Override
    public String toString() {
        return "tienda{" + "ID=" + ID + ", producto=" + producto + ", domicilio=" + domicilio + ", representante=" + representante + '}';
    }
    

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public HashMap<producto, Integer> getProducto() {
        return producto;
    }

    public void setProducto(HashMap<producto, Integer> producto) {
        this.producto = producto;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getRepresentante() {
        return representante;
    }

    public void setRepresentante(String representante) {
        this.representante = representante;
    }

    
    
    
    
}
