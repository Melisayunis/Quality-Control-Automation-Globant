/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Mascota;
import Entidades.Usuario;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Usuario
 */
public class UsuarioService {

    MascotaService ms = new MascotaService();
    Set<Usuario> usuarios = new HashSet<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
   
    
    public void mostrarMascotasUsuario(){
         Set<Mascota> listaMascotas = ms.getListaMascotas();
         System.out.println("Ingrese el nombre de una mascota");

        String nom = leer.next();

        for (Mascota mascota : listaMascotas) {
            System.out.println(mascota.toString());
           
        }
        
    }

    public void inicializarUsuarios() {
        List<Mascota> usuarioMascotas = new ArrayList();
        // public Usuario(int id, String nombre, String dni, LocalDate fechaNacimiento, List<Mascota> mascotas)
        Usuario u1 = new Usuario("Jaz", "40666837", LocalDate.of(1997, 9, 13), usuarioMascotas);
        Usuario u2 = new Usuario("Inti", "68461227", LocalDate.of(2017, 7, 13), usuarioMascotas);
        Usuario u3 = new Usuario("Cristian", "12345678", LocalDate.of(1984, 12, 03), usuarioMascotas);
        Usuario u4 = new Usuario("Olivia", "34567897", LocalDate.of(2017, 6, 13), usuarioMascotas);

        usuarios.add(u1);
        usuarios.add(u2);
        usuarios.add(u3);
        usuarios.add(u4);
    }

    public Usuario crearUsuario(Mascota mnueva) {

        Usuario s = new Usuario();
        List<Mascota> mascUser = new ArrayList();
        
        System.out.println("Ingrese el nombre completo del nuevo usuario: ");
        s.setNombre(leer.next());
        System.out.println("Ingrese su DNI");
        s.setDni(leer.next());
        System.out.println("Ingrese su año de nacimiento con 4 dígitos: ");
        int anio = leer.nextInt();
        System.out.println("Ingrese el mes de nacimiento sin 0 adelante: ");
        int mes = leer.nextInt();
        System.out.println("Ingrese el dia de nacimiento: ");
        int dia = leer.nextInt();
        s.setFechaNacimiento(LocalDate.of(anio, mes, dia));

        mascUser.add(mnueva);

        s.setMascotas(mascUser);

        usuarios.add(s);
        System.out.println(s.toString());
        
        return s;

    }

    public void crearUsuarioSM() {
        List<Mascota> mascUser = new ArrayList();

        Usuario s = new Usuario();
        
        System.out.println("Ingrese el nombre completo del nuevo usuario: ");
        s.setNombre(leer.next());
        System.out.println("Ingrese su DNI");
        s.setDni(leer.next());
        System.out.println("Ingrese su año de nacimiento con 4 dígitos: ");
        int anio = leer.nextInt();
        System.out.println("Ingrese el mes de nacimiento sin 0 adelante: ");
        int mes = leer.nextInt();
        System.out.println("Ingrese el dia de nacimiento: ");
        int dia = leer.nextInt();
        s.setFechaNacimiento(LocalDate.of(anio, mes, dia));
        s.setMascotas(mascUser);

        usuarios.add(s);
        System.out.println(s.toString());

    }

    public void mostrarUsuarios() {
        for (Usuario usuario : usuarios) {
            System.out.println(usuario.toString());
        }
    }
    
    public Usuario buscarUsuarioPorNombre(String userName){
        for (Usuario usuario : usuarios) {
            if(usuario.getNombre().equalsIgnoreCase(userName)){
                return usuario;
            }
        }
        
        Usuario usuariov = new Usuario();
        return usuariov;
    }

}


