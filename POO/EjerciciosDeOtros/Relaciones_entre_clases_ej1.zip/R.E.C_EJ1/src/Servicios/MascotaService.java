/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Mascota;
import Entidades.Usuario;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Usuario
 */
public class MascotaService {

    Set<Mascota> listaMascotas = new HashSet<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public Set<Mascota> getListaMascotas() {
        return listaMascotas;
    }

    public void setListaMascotas(Set<Mascota> listaMascotas) {
        this.listaMascotas = listaMascotas;
    }

    public void inicializarMascotas() {
        Usuario u1 = new Usuario("Jaz", "40666837", LocalDate.of(1997, 9, 13), null);
        //(String nombre, String especie, String raza, String color, int edad, boolean adoptado)
        Mascota m1 = new Mascota("Ramon", u1, "Gato", "Sin raza", "Naranja", 15, true);
        Mascota m2 = new Mascota("Peperina", "Perro", "Sin raza", "Rubio", 7, false);
        Mascota m3 = new Mascota("Oliverio", "Perro", "Caniche", "Negro", 6, false);
        Mascota m4 = new Mascota("Cola Cortada", "Gato", "Sin raza", "Gris", 2, false);

        listaMascotas.add(m1);
        listaMascotas.add(m2);
        listaMascotas.add(m3);
        listaMascotas.add(m4);
    }

    public void agregarMascota() {
        Mascota m = new Mascota();

        System.out.println("Ingrese el nombre de la mascota:");
        m.setNombre(leer.next());
        System.out.println("Ingrese la especie de la mascota:");
        m.setEspecie(leer.next());
        System.out.println("Ingrese la raza de la mascota:");
        m.setRaza(leer.next());
        System.out.println("Ingrese el color de la mascota:");
        m.setColor(leer.next());
        System.out.println("Ingrese la edad de la mascota:");
        m.setEdad(leer.nextInt());

        Mascota mCompare = buscarMascotaPorNombre(m.getNombre());

        if ((mCompare.getNombre().equalsIgnoreCase(m.getNombre())) && (mCompare.getEspecie().equalsIgnoreCase(m.getEspecie()) && (mCompare.getColor().equalsIgnoreCase(m.getColor())) && (mCompare.getEdad() == m.getEdad()))) {
            System.out.println("La mascota ya está registrada en el sistema.");
            System.out.println(mCompare.toString());
        } else {

            listaMascotas.add(m);
            System.out.println("Se agregó a " + m.getNombre() + " al sistema.");
        }
    }

    public void mostrarMascotas() {

        for (Mascota mascota : listaMascotas) {

            if (!mascota.isAdoptado()) {
                System.out.println("Mascota -->" + " Nombre: " + mascota.getNombre() + "; Especie: " + mascota.getEspecie() + "; Raza: " + mascota.getRaza() + "; Color: " + mascota.getColor() + "; Adoptada: No adoptada" );

            }else{
                 System.out.println("Mascota -->" + " Nombre: " + mascota.getNombre() + "; Especie: " + mascota.getEspecie() + "; Raza: " + mascota.getRaza() + "; Color: " + mascota.getColor() + "; Adoptada: Adoptada"  + "; Dueño: " + mascota.getDuenio().getNombre());
            }

        }
    }

    public Mascota buscarMascotaPorNombre(String nombreMascota) {

        for (Mascota mascota : listaMascotas) {

            if (mascota.getNombre().equalsIgnoreCase(nombreMascota)) {

                return mascota;
            }

        }

        Mascota mascotav = new Mascota();

        return mascotav;

    }

    public void eliminarMascota(String nombreMasc) {
        Iterator<Mascota> it = listaMascotas.iterator();
        int cont = 0;
        while (it.hasNext()) {
            if (it.next().getNombre().equalsIgnoreCase(nombreMasc)) {
                System.out.println("Seguro que desea eliminar a " + nombreMasc + "? (s / n)");
                String respuesta = leer.next();
                if (respuesta.equalsIgnoreCase("s")) {
                    it.remove();
                    System.out.println("La mascota " + nombreMasc + " ha sido removida del sistema.");
                    cont++;
                }
            }
        }
        if (cont == 0) {
            System.out.println("No se encontró la mascota.");
        }
    }

    public void asignarUsuarioaMascota(Usuario u, Mascota m) {
        System.out.println(u.getNombre());
        
        for (Mascota mascota : listaMascotas) {
            if (m.getNombre().equalsIgnoreCase(mascota.getNombre()) && m.getEspecie().equalsIgnoreCase(mascota.getEspecie()) && m.getEdad() == mascota.getEdad()) {
               mascota.setDuenio(u);
                mascota.setAdoptado(true);
            }
        }
    }

}
