/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package r.e.c_ej1;

import Entidades.Mascota;
import Entidades.Usuario;
import Servicios.MascotaService;
import Servicios.UsuarioService;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class REC_EJ1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        UsuarioService us = new UsuarioService();
        MascotaService ms = new MascotaService();
        us.inicializarUsuarios();
        ms.inicializarMascotas();
        int selec = -1;

        do {
            System.out.println("");
            System.out.println("Bienvenidx al menú.");
            
        System.out.println("       /\\");  
        System.out.println("      /  \\");
        System.out.println("     /    \\");
        System.out.println("    /      \\");
        System.out.println("   /        \\");
        System.out.println("  /          \\");
        System.out.println(" /            \\");
        System.out.println("/______________\\");
        System.out.println("| proximamente |");
        System.out.println("|          __  |");
        System.out.println("|         |  | |");
        System.out.println("|         |__| |");
        System.out.println("|______________|");
            
            System.out.println("Presione 1 para ver el menú de Mascotas");
            System.out.println("Presione 2 para ver el menú de Usuarios");
            System.out.println("Presione 0 para salir");
            System.out.println("");
            selec = leer.nextInt();

            switch (selec) {

                case 1:

                    do {
                        System.out.println("");
                        System.out.println("Presione 1 para agregar una mascota");
                        System.out.println("Presione 2 para visualizar todas las mascotas");
                        System.out.println("Presione 3 para buscar una mascota por su nombre");
                        System.out.println("Presione 4 para eliminar una mascota");
                        System.out.println("Presione 9 para volver al menú anterior");
                        System.out.println("");
                        selec = leer.nextInt();

                        switch (selec) {
                            case 1:
                                ms.agregarMascota();
                                break;
                            case 2:
                                ms.mostrarMascotas();
                                break;
                            case 3:
                                System.out.println("Ingrese el nombre de la mascota que desea buscar:");
                                String nom = leer.next();
                                if((ms.buscarMascotaPorNombre(nom)).getNombre()==null){
                                    System.out.println("No se encontró la mascota.");
                                }else{
                                System.out.println(ms.buscarMascotaPorNombre(nom).toString());
                                }
                                break;
                            case 4:
                                System.out.println("Ingrese el nombre de la mascota que desea eliminar: ");
                                nom = leer.next();
                                ms.eliminarMascota(nom);
                                break;
                            case 9:
                                break;
                            default:
                                System.out.println("La opción seleccionada es inválida.");
                        }

                    } while (selec != 9);

                    break;

                case 2:

                    do {
                        System.out.println("");
                        System.out.println("Presione 1 para agregar un usuario");
                        System.out.println("Presione 2 para ver todos los usuarios");
                        System.out.println("Presione 3 para adoptar una mascota");
                        System.out.println("Presione 4 para ver las mascotas de un usuario");
                        System.out.println("Presione 5 para eliminar un usuario");
                        System.out.println("Presione 9 para volver al menú anterior");
                        System.out.println("");
                        selec = leer.nextInt();

                        switch (selec) {
                            case 1:
                                System.out.println("Tiene mascotas ingresadas? (s / n) ");
                                String rta = leer.next();
                                
                                if (rta.equalsIgnoreCase("s")) {

                                    System.out.println("Ingrese el nombre de la mascota que desea buscar:");
                                    String nom = leer.next();

                                    Mascota mnueva = ms.buscarMascotaPorNombre(nom);
                                    
                                    if(mnueva.getNombre()==null){
                                        System.out.println("No se encontró la mascota Se creará el usuario sin mascota.");
                                        System.out.println("");
                                        us.crearUsuarioSM();
                                    }else{
                                    System.out.println("Se asignó a " + mnueva.getNombre().toUpperCase() + " a su usuario.");
                                    Usuario u = us.crearUsuario(mnueva);
                                    ms.asignarUsuarioaMascota(u, mnueva);
                                    }
                                }else{
                                 
                                    us.crearUsuarioSM();
                                }
                                    break;

                        case 2:
                                us.mostrarUsuarios();
                                break;
                            case 3:
                                break;
                            case 4:
                                break;
                            case 7:
                                us.mostrarMascotasUsuario();
                                break;
                            case 9:
                                break;
                            default:
                                System.out.println("La opción seleccionada es inválida.");
                        }

                    } while (selec != 9);

                        break;

                      case 0:
                    
                    System.out.println("Gracias por su visita!");
                    break;
                    
                default:
                    System.out.println("La opción seleccionada es inválida.");
            }
            
        
            
            }
            while (selec != 0);

        }


    
    }
