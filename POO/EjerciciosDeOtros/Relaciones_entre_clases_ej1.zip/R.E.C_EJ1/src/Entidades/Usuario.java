/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Usuario
 */
public class Usuario implements Comparable<Usuario>{
    private String nombre;
    private String dni;
    private LocalDate fechaNacimiento;
    
    private List<Mascota> mascotas;

    public Usuario() {
    }

    public Usuario(String nombre, String dni, LocalDate fechaNacimiento, List<Mascota> mascotas) {
        this.nombre = nombre;
        this.dni = dni;
        this.fechaNacimiento = fechaNacimiento;
        this.mascotas = mascotas;
    }
    
    


    public String getNombre() {
        return nombre;
     
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public List<Mascota> getMascotas() {
        return mascotas;
    }

    public void setMascotas(List<Mascota> mascotas) {
        this.mascotas = mascotas;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.dni, other.dni)) {
            return false;
        }
        if (!Objects.equals(this.fechaNacimiento, other.fechaNacimiento)) {
            return false;
        }
        if (!Objects.equals(this.mascotas, other.mascotas)) {
            return false;
        }
        return true;
    }
    
    public String mostrarMascotas(){
        String mascotasMostrar = "";
        for (Mascota mascota : mascotas) {
           mascotasMostrar = mascota.getNombre() + ", ";
        }
        
        return mascotasMostrar;
    }

    @Override
    public String toString() {
        return "Usuario{" + "Nombre: " + nombre + ", DNI: " + dni + ", F.Nac: " + fechaNacimiento + ", Mascotas: " + mostrarMascotas() + '}';
    }

    @Override
    public int compareTo(Usuario t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

}
