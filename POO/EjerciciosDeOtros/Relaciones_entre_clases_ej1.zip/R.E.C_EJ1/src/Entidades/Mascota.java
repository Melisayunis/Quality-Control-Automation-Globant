/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.util.Objects;

/**
 *
 * @author Usuario
 */
public class Mascota {
    private String nombre;
    private Usuario duenio;
    private String especie;
    private String raza;
    private String color;
    private int edad;
    private boolean adoptado;

    public Mascota() {
    }

    public Mascota(String nombre, Usuario duenio, String especie, String raza, String color, int edad, boolean adoptado) {
        this.nombre = nombre;
        this.duenio = duenio;
        this.especie = especie;
        this.raza = raza;
        this.color = color;
        this.edad = edad;
        this.adoptado = adoptado;
    }

    public Mascota(String nombre, String especie, String raza, String color, int edad, boolean adoptado) {
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.color = color;
        this.edad = edad;
        this.adoptado = adoptado;
    }
    
    

    public Usuario getDuenio() {
        return duenio;
    }

    public void setDuenio(Usuario duenio) {
        this.duenio = duenio;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isAdoptado() {
        return adoptado;
    }

    public void setAdoptado(boolean adoptado) {
        this.adoptado = adoptado;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Mascota other = (Mascota) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.especie, other.especie)) {
            return false;
        }
        if (!Objects.equals(this.raza, other.raza)) {
            return false;
        }
        if (!Objects.equals(this.color, other.color)) {
            return false;
        }
        return true;
    }


    

    @Override
    public String toString() {
        return "Mascota --> " + "Nombre: " + nombre + "; Especie:" + especie + "; Raza: " + raza + "; Color: " + color + "; Edad: " +   "; Dueño: " + duenio.toString() + "; Adoptado: " + adoptado + '}';
    }
    
    
    
    

    
    
    
    
}
