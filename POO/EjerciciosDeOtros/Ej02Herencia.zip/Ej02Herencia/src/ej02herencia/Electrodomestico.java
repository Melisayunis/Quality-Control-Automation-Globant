package ej02herencia;

import java.util.Scanner;

public class Electrodomestico {

    protected double precio;
    protected String color;
    protected char consumoEn;
    protected double peso;

    public Electrodomestico() {
    }

    public Electrodomestico(double precio, String color, char consumoEn, double peso) {
        this.precio = precio;
        this.color = color;
        this.consumoEn = consumoEn;
        this.peso = peso;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public char getConsumoEn() {
        return consumoEn;
    }

    public void setConsumoEn(char consumoEn) {
        this.consumoEn = consumoEn;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    /*Método comprobarConsumoEnergetico(char letra): comprueba que la letra es correcta,
    sino es correcta usara la letra F por defecto. Este método se debe invocar al crear el
    objeto y no será visible.
     */
    public void comprobarConsumoEnergetico(char letra) {
        if (letra >= 'A' && letra <= 'F') {
            consumoEn = letra;
        } else {
            System.out.println("Letra ingresada no valida, se le asignara letra por defecto('F')");
            consumoEn = 'F';
        }

    }

    /* Método comprobarColor(String color): comprueba que el color es correcto, y si no lo es,
    usa el color blanco por defecto. Los colores disponibles para los electrodomésticos son
    blanco, negro, rojo, azul y gris. No importa si el nombre está en mayúsculas o en
    minúsculas. Este método se invocará al crear el objeto y no será visible.
     */
    public void comprobarColor(String color) {
        if (color.equalsIgnoreCase("blanco") || color.equalsIgnoreCase("negro") || color.equalsIgnoreCase("rojo")
                || color.equalsIgnoreCase("azul") || color.equalsIgnoreCase("gris")) {
            this.color = color;
        } else {
            System.out.println("Color ingresado no valido se le asignara color por defecto('Blanco')");
            this.color = "Blanco";
        }
    }

    /*
    Metodo crearElectrodomestico(): le pide la información al usuario y llena el
electrodoméstico, también llama los métodos para comprobar el color y el consumo. Al
precio se le da un valor base de $1000.
     */
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearElectrodomestico() {
        System.out.println("Color: ");
        color = leer.next();
        comprobarColor(color);
        System.out.println("Consumo Energetico: ");
        consumoEn = leer.next().charAt(0);
        comprobarConsumoEnergetico(consumoEn);
        System.out.println("Peso: ");
        peso = leer.nextDouble();
        precio = 1000;
       
    }

    /*
    Método precioFinal(): según el consumo energético y su tamaño, aumentará el valor del
    precio.
     */
    public double precioFinal() {
        int precioFinal = 0;
        switch (consumoEn) {
            case 'A':
                precioFinal = 1000;
                break;
            case 'B':
                precioFinal = 800;
                break;
            case 'C':
                precioFinal = 600;
                break;
            case 'D':
                precioFinal = 500;
                break;
            case 'E':
                precioFinal = 300;
                break;
            case 'F':
                precioFinal = 100;
                break;
        }
        if (peso >= 1 && peso <= 19) {
            precioFinal += 100;
        }
        if (peso >= 20 && peso <= 49) {
            precioFinal += 500;
        }
        if (peso >= 50 && peso <= 79) {
            precioFinal += 800;
        }
        if (peso >= 80) {
            precioFinal += 1000;
        }
        return precioFinal;
    }

}
