/*
Se debe crear también una subclase llamada Televisor con los siguientes atributos:
resolución (en pulgadas) y sintonizador TDT (booleano), además de los atributos
heredados.
*/
package ej02herencia;

import java.util.Scanner;

public class Televisor extends Electrodomestico {
    public double pulgadas;
    public boolean tdt;

    public Televisor() {
    }

    public Televisor(double pulgadas, boolean tdt, double precio, String color, char consumoEn, double peso) {
        super(precio, color, consumoEn, peso);
        this.pulgadas = pulgadas;
        this.tdt = tdt;
    }

    public double getPulgadas() {
        return pulgadas;
    }

    public void setPulgadas(double pulgadas) {
        this.pulgadas = pulgadas;
    }

    public boolean isTdt() {
        return tdt;
    }

    public void setTdt(boolean tdt) {
        this.tdt = tdt;
    }

    /*
    Método crearTelevisor(): este método llama a crearElectrodomestico() de la clase
    padre, lo utilizamos para llenar los atributos heredados del padre y después llenamos
    los atributos del televisor
    */
    
    public void crearTelevisor(){
        crearElectrodomestico();
        System.out.println("Pulgas del televisor:");
        pulgadas = leer.nextDouble();
        System.out.println("Contiene sintonizador TDT (True/False)");
        tdt = leer.nextBoolean();
    }
    
    /*
    Método precioFinal(): este método será heredado y se le sumará la siguiente
    funcionalidad. Si el televisor tiene una resolución mayor de 40 pulgadas, se
    incrementará el precio un 30% y si tiene un sintonizador TDT incorporado, aumentará
    $500. Recuerda que las condiciones que hemos visto en la clase Electrodomestico
    también deben afectar al precio
    */
    public double precioFinalTelevisor(){
        double precioFinal =precio+precioFinal();
        if (pulgadas>=40) {
            precioFinal+= (precioFinal*0.30);
            
        }
        if (tdt) {
            precioFinal+= 500;
        }
        precio = precioFinal;
        return precioFinal;
    }
      @Override
    public String toString() {
        return "Televisor: "
                + "\nPrecio: "+precio 
                + "\nColor: "+color 
                + "\nConsumo energetico: "+consumoEn
                + "\nPulgadas: "+pulgadas
                + "\nSintonizador TDT: "+tdt;
        
    }
    
}
