/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej02herencia;

import java.util.ArrayList;

public class Ej02Herencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Electrodomestico> electrodomesticos= new ArrayList();
        Lavadora l1 =  new Lavadora();
        Televisor t1 = new Televisor();
        Lavadora l2 =  new Lavadora();
        Televisor t2 = new Televisor();
        System.out.println("Complete los datos de las lavadoras");
        l1.crearLavadora();
        l2.crearLavadora();
        System.out.println("Complete los datos de los televisores");
        t1.crearTelevisor();
        t2.crearTelevisor();
        l1.precioFinalLavadora();
        l2.precioFinalLavadora();
        t1.precioFinalTelevisor();
        t2.precioFinalTelevisor();
        electrodomesticos.add(l1);
        electrodomesticos.add(l2);
        electrodomesticos.add(t1);
        electrodomesticos.add(t2);
        
        for (Electrodomestico e: electrodomesticos) {
            System.out.println("El precio final del electrodomestico es : $"+e.precio);
            
        }
        double sumaTotal = 0, sumaLav=0, sumaTel=0;
        for (Electrodomestico e: electrodomesticos) {
            sumaTotal+=e.precio;
            if (e instanceof Lavadora) {
                sumaLav+=e.precio;
            }
            if (e instanceof Televisor) {
                sumaTel+=e.precio;
            }
        }
        System.out.println("La suma total del precio de los electrodomesticos es : $"+sumaTotal);
        System.out.println("La suma total del precio de los televisores es : $"+sumaTel);
        System.out.println("La suma total del precio de las lavarropas es : $"+sumaLav);
        
//        System.out.println("El precio final de la lavadora sera : $"+l1.precioFinalLavadora());
//        t1.crearTelevisor();
//        System.out.println("El precio final del televisor sera : $"+t1.precioFinalTelevisor());
        
        
    }
}
