/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.ejer6.extra;

import Entidad.Ahorcado;
import Servicio.ahorcadoServicio;

/**
 *
 * @author Usuario
 */
public class POOEjer6EXTRA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      ahorcadoServicio as=new ahorcadoServicio();
      Ahorcado a;
      a=as.crearJuego();
      as.juego(a);
     
    }
    
}
