/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author Usuario
 */
public class Ahorcado {
    private int longi, jugadasMax, letrasEcontradas;
    private String[] vector= new String[longi];
    private String[] vectorRespuesta=new String[longi];

    public Ahorcado() {
    }

    public String[] getVectorRespuesta() {
        return vectorRespuesta;
    }

    public void setVectorRespuesta(String[] vectorRespuesta) {
        this.vectorRespuesta = vectorRespuesta;
    }

    public Ahorcado(int longi, int jugadasMax, int letrasEcontradas, String [] vector,String [] vectorRespuesta) {
        this.longi = longi;
        this.jugadasMax = jugadasMax;
        this.letrasEcontradas = letrasEcontradas;
        this.vector=vector;
        this.vectorRespuesta=vectorRespuesta;
    }

    public int getLongi() {
        return longi;
    }

    public void setLongi(int longi) {
        this.longi = longi;
    }

    public int getJugadasMax() {
        return jugadasMax;
    }

    public void setJugadasMax(int jugadasMax) {
        this.jugadasMax = jugadasMax;
    }

    public int getLetrasEcontradas() {
        return letrasEcontradas;
    }

    public void setLetrasEcontradas(int letrasEcontradas) {
        this.letrasEcontradas = letrasEcontradas;
    }

    public String[] getVector() {
        return vector;
    }

    public void setVector(String[] vector) {
        this.vector = vector;
    }


    
    
    
}
