/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Ahorcado;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class ahorcadoServicio {
     Scanner leer = new Scanner(System.in).useDelimiter("\n");
   
     
    public Ahorcado crearJuego() {
        System.out.println("Ingrese la palabra a adivinar");
        String palabra = leer.next();
        System.out.println("Ingrese la cantidad de jugadas máximas");
        int jugadas = leer.nextInt();
        int longi = palabra.length();
        String[] vector = new String[longi];
        for (int i = 0; i < longi; i++) {
            vector[i] = palabra.substring(i, i+1);
        }
        String [] vectorRespuesta= new String[longi];
        Arrays.fill(vectorRespuesta,"_");
        return new Ahorcado(longi, jugadas, 0, vector,vectorRespuesta);
    }
    public int longitud(Ahorcado a) {
        return a.getLongi();
    }
    
    /*Método buscar(letra): este método recibe una letra dada por el usuario y busca sila
letra ingresada es parte de la palabra o no. También informará si la letra estaba o no.*/
    public boolean buscar(Ahorcado a, String letra){
        boolean encontreLetra=false;
          
        for (int i = 0; i < longitud(a); i++) {
         if (a.getVector()[i].equalsIgnoreCase(letra)) {
                encontreLetra=true;
                break;       
        }
        }
        return encontreLetra;
        
        
    }
    
    public void encontradas(Ahorcado a, String letra){
        
        int c=0;
      
        if (buscar(a, letra)){ 
            for (int i = 0; i < longitud(a); i++) {
         if (a.getVector()[i].equalsIgnoreCase(letra)) {
             c+=1;
             a.getVectorRespuesta()[i]=a.getVector()[i];
             }
            }
            a.setLetrasEcontradas(a.getLetrasEcontradas()+c);
            System.out.println("La letra fue encontrada ");
            for (int i = 0; i < longitud(a); i++) {
                 System.out.print(a.getVectorRespuesta()[i]); 
             }
            System.out.println(" ");
        }else{
            System.out.println("La letra no se encontró");
            
        }
        System.out.println("Cantidad de letras econtradas "+a.getLetrasEcontradas());
        System.out.println("Cantidad de letras faltantes "+(a.getLongi()-a.getLetrasEcontradas()));
    }
    public int intentos(Ahorcado a){
       int intentos= a.getJugadasMax()-1;
     a.setJugadasMax(intentos);
        System.out.println("Cantidad de intentos restantes "+intentos);
     return a.getJugadasMax();
    } 
    public void juego (Ahorcado a){
        int intentos;
        intentos=a.getJugadasMax();
        System.out.println("La longitud de la palabra es "+longitud(a));
        do{
        System.out.println("Ingrese una letra ");
        String letra= leer.next();
      encontradas(a,letra);
     if (!(buscar(a,letra))){
         intentos=intentos(a);
     }
        } while ((intentos>0) && (a.getLetrasEcontradas()<a.getLongi()));
            
      if (intentos==0){
          System.out.println("Se quedó sin intentos");
      }
      
    }
}
