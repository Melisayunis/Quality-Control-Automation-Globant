package org.example.ejercicio01.entity;

public class Perro extends Animal{


	//El super lo usamos para llamar al constructor de la clase padre
	public Perro(String nombre, String alimento, int edad, String raza) {
		super(nombre, alimento, edad, raza);
	}

}
