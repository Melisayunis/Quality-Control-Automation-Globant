package org.example.ejercicio00;

public interface Pepito {

	public void saludo();


	public int sumar();


	public int resta();


	public void multiplicar();

}
