package org.example.ejercicio00;

public class Main2 implements Pepito{

	@Override
	public void saludo() {
		System.out.println("Hola Egg");
	}

	@Override
	public int sumar() {
		return 0;
	}

	@Override
	public int resta() {
		return  6 - 2;
	}

	@Override
	public void multiplicar() {}

}
