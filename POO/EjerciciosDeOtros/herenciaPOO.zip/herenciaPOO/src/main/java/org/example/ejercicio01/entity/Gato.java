package org.example.ejercicio01.entity;

public class Gato extends Animal{

	public Gato(String nombre, String alimento, int edad, String raza) {
		super(nombre, alimento, edad, raza);
	}
}
