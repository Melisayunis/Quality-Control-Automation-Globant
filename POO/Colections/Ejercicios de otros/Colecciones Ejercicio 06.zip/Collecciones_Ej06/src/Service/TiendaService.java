/*
6)Se necesita una aplicación para una tienda en la cual queremos almacenar los distintos
productos que venderemos y el precio que tendrán. Además, se necesita que la
aplicación cuente con las funciones básicas.
Estas las realizaremos en el servicio. Como, introducir un elemento, modificar su precio,
eliminar un producto y mostrar los productos que tenemos con su precio (Utilizar
Hashmap). El HashMap tendrá de llave el nombre del producto y de valor el precio.
Realizar un menú para lograr todas las acciones previamente mencionadas.
 */
package Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class TiendaService {
    private final Scanner read = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    private HashMap<String, Double> tienda = new HashMap();
    
    public void cargarTienda(){
        tienda.put("Arvejas", 1.50);
        tienda.put("Tomates", 0.50);
        tienda.put("Harina", 1.80);
        tienda.put("Pan", 2.50);
        tienda.put("Leche", 1.00);
        tienda.put("Papas", 1.55);
        tienda.put("Zanahorias", 0.80);
    }
    
    public void agregaraTienda(){
        System.out.print("Ingrese el nombre del producto: ");
        String producto = read.next().toLowerCase();
        producto = producto.toUpperCase().charAt(0) + producto.substring(1, producto.length());
        System.out.print("Ingrese el precio del producto: ");
        Double precio = read.nextDouble();
        tienda.put(producto, precio);
    }
    
    public void modificarProducto(){
        System.out.print("Ingrese el producto que desea modificar: ");
        String producto = read.next();
        if (tienda.containsKey(producto)){
                System.out.print("Ingrese el nuevo precio: ");
                Double precio = read.nextDouble();
                tienda.put(producto, precio);
                System.out.println("Se modificó el precio de manera exitosa");
            }else System.out.println("El producto que desea modificar no se encuentra en la tienda.");
    }
    
    public void eliminarProducto(){
        System.out.print("Ingrese el producto que desea eliminar: ");
        String producto = read.next();
        if (tienda.containsKey(producto)){
                tienda.remove(producto);
                System.out.println("Se eliminó el producto de manera exitosa");
            }else System.out.println("El producto que desea eliminar no se encuentra en la tienda.");
    }
    
    public void mostrarProducto(){
        //System.out.println(tienda.toString());
        for (Map.Entry<String, Double> entry : tienda.entrySet()) {
            System.out.println("El producto " + entry.getKey() + " tiene un valor de: $" + entry.getValue());
        }
    }
}
