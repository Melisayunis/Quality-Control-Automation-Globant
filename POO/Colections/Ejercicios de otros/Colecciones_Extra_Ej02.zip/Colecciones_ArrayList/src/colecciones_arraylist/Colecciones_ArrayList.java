/*
1)Diseñar un programa que lea y guarde razas de perros en un ArrayList de tipo String. El
programa pedirá una raza de perro en un bucle, el mismo se guardará en la lista y
después se le preguntará al usuario si quiere guardar otro perro o si quiere salir. Si decide
salir, se mostrará todos los perros guardados en el ArrayList.
2)Continuando el ejercicio anterior, después de mostrar los perros, al usuario se le pedirá
un perro y se recorrerá la lista con un Iterator, se buscará el perro en la lista. Si el perro
está en la lista, se eliminará el perro que ingresó el usuario y se mostrará la lista
ordenada. Si el perro no se encuentra en la lista, se le informará al usuario y se mostrará
la lista ordenada.
 */
package colecciones_arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;


public class Colecciones_ArrayList {

    
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
        ArrayList <String> perros = new ArrayList();
        String onoff = "s", razaEliminar;
        boolean estaono=false;
        do{
            System.out.print("Ingrese la raza del perrito: ");
            
            perros.add(read.next());
            
            System.out.print("¿Desea Agregar otra raza de perrito? (S/N)");
            
            onoff = read.next();
                    
        }while(onoff.equalsIgnoreCase("s"));
        System.out.println("\n-----------------ooooooooooooo-----------------\n");
        for (String p : perros) {
            System.out.println((perros.indexOf(p)+1) + " La raza del perro es: " + p);
        }
        System.out.println("\n-----------------ooooooordenando-----------------\n");
        Collections.sort(perros);
        System.out.print("Ingrese la raza del perro a eliminar: ");
        razaEliminar = read.next();
        Iterator<String> it = perros.iterator();
        while(it.hasNext()){
            if(it.next().equalsIgnoreCase(razaEliminar)){
                it.remove();
                estaono = true;
            }
        }
        if(!estaono){
                System.out.println("La raza no se encuentra en la lista.");
            }
        System.out.println("\n-----------------ooooooooooooo-----------------\n");
        for (String p : perros) {
            System.out.println((perros.indexOf(p)+1) + " La raza del perro es: " + p);
        }
        
    }
    
}
