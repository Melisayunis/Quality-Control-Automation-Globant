/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda;

import Producto.Producto;
import java.util.ArrayList;

/**
 *
 * @author Emanuel
 */
public class Tienda {
        private ArrayList<Producto> inventario;

    public Tienda() {
        inventario = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        inventario.add(producto);
    }

    public boolean venta(String nombreProducto) {
        for (Producto producto : inventario) {
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {
                if (producto.getCantidadInventario() > 0) {
                    producto.setCantidadInventario(producto.getCantidadInventario() - 1);
                    return true;
                } else {
                    System.out.println("No hay suficiente inventario para vender " + nombreProducto);
                    return false;
                }
            }
        }
        System.out.println("Producto no encontrado: " + nombreProducto);
        return false;
    }

    public void reposicion(String nombreProducto) {
        for (Producto producto : inventario) {
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {
                producto.setCantidadInventario(producto.getCantidadInventario() + 1);
                System.out.println("Se ha repuesto el producto: " + nombreProducto);
                return;
            }
        }
        System.out.println("Producto no encontrado: " + nombreProducto);
    }

    public void mostrarProductos() {
        System.out.println("Inventario de la tienda:");
        for (Producto producto : inventario) {
            System.out.println(producto);
        }
    }
}
