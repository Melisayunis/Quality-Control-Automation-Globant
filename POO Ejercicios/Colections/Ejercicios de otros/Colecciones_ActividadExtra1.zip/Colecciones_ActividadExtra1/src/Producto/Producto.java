/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Producto;

/**
 *
 * @author Emanuel
 */
public class Producto {
    private String nombre;
    private String categoria;
    private double precio;
    private int cantidadInventario;

    public Producto(String nombre, String categoria, double precio, int cantidadInventario) {
       this.nombre = nombre;
       this.categoria = categoria;
       this.precio = precio;
       this.cantidadInventario = cantidadInventario;
    }
        
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidadInventario() {
        return cantidadInventario;
    }

    public void setCantidadInventario(int cantidadInventario) {
        this.cantidadInventario = cantidadInventario;
    }
    
    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Categoría: " + categoria + ", Precio: " + precio + ", Cantidad en inventario: " + cantidadInventario;
    }
}

