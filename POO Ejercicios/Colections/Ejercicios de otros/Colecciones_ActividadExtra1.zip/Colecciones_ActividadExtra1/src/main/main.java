/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import Producto.Producto;
import Tienda.Tienda;
import java.util.Scanner;

/**
 *
 * @author Emanuel
 */
public class main {
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Tienda tienda = new Tienda();

        boolean continuar = true;
        while (continuar) {
            System.out.println("Ingrese la opción: \n1. Agregar producto \n2. Venta de producto \n3. Reposición de producto \n4. Mostrar inventario \n5. Salir");
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nombre del producto:");
                    String nombre = scanner.nextLine();
                    System.out.println("Ingrese la categoría del producto:");
                    String categoria = scanner.nextLine();
                    System.out.println("Ingrese el precio del producto:");
                    double precio = scanner.nextDouble();
                    System.out.println("Ingrese la cantidad en inventario del producto:");
                    int cantidad = scanner.nextInt();
                    scanner.nextLine();
                    Producto nuevoProducto = new Producto(nombre, categoria, precio, cantidad);
                    tienda.agregarProducto(nuevoProducto);
                    break;

                case 2:
                    System.out.println("Ingrese el nombre del producto que desea comprar:");
                    String productoVenta = scanner.nextLine();
                    tienda.venta(productoVenta);
                    break;

                case 3:
                    System.out.println("Ingrese el nombre del producto que desea reponer:");
                    String productoReposicion = scanner.nextLine();
                    tienda.reposicion(productoReposicion);
                    break;

                case 4:
                    tienda.mostrarProductos();
                    break;

                case 5:
                    continuar = false;
                    break;

                default:
                    System.out.println("Opción inválida, por favor intente nuevamente.");
            }
        }
        scanner.close();
    }
}
    