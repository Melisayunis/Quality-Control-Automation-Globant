/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Entidad.Producto;
import java.util.Scanner;

/**
 *
 * @author Nicolàs Medina
 */
public class ProductoServicio {
    
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public Producto crearProducto() {
        
        Producto P1 = new Producto();
        System.out.println("Ingrese el nombre del producto");
        P1.setNombre(leer.next());
        System.out.println("Ingrese la categoria del producto");
        P1.setCategoria(leer.next());
        System.out.println("Ingrese el precio");
        P1.setPrecio(leer.nextDouble());
        System.out.println("Ingrese la cantidad de stock");
        P1.setStock(leer.nextInt());
        
        return P1;
    }
    
    
}
