/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Entidad.Producto;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nicolàs Medina
 */
public class Tienda {

    // Método venta():Método reposición():Método toString
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public boolean venta(ArrayList< Producto> p) {

        System.out.println("Ingrese el nombre del producto que quiere buscar: ");
        String nombreProducto = leer.next();
        boolean b = false;

        for (Producto producto : p) {
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {
                if (producto.getStock() > 0) {
                    producto.setStock(producto.getStock() - 1);
                    b = true;
                }
            }
        }
        return b;
    }

    public void reposicion(ArrayList< Producto> p) {
        System.out.println("Ingrese el nombre del producto que quiere reponer: ");
        String nombreProducto = leer.next();

        for (Producto producto : p) {
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {

                producto.setStock(producto.getStock() + 1);
            }
        }
    }

    public void mostrarProducto(ArrayList< Producto> p) {

        for (Producto producto : p) {
            System.out.println(producto.toString());
        }
    }

    public void modificar(ArrayList< Producto> p) {
        System.out.println("Ingrese el nombre del producto que quiere modificar: ");
        String nombreProducto = leer.next();

        for (int i = 0; i < p.size(); i++) {
            Producto producto = p.get(i);
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {

                System.out.println("Ingresa el nuevo nombre del produto");
                producto.setNombre(leer.next());
                System.out.println("Ingrese la nueva categoria del producto");
                producto.setCategoria(leer.next());
                System.out.println("Ingrese el cambio de precio");
                producto.setPrecio(leer.nextDouble());
                System.out.println("Ingrese la cantidad de stock");
                producto.setStock(leer.nextInt());
            }
        }
    }

    public void eliminar(ArrayList< Producto> p) {
        System.out.println("Ingrese el nombre del producto que quiere eliminar: ");
        String nombreProducto = leer.next();

        for (int i = 0; i < p.size(); i++) {
            Producto producto = p.get(i);
            if (producto.getNombre().equalsIgnoreCase(nombreProducto)) {
                p.remove(producto);
            }
        }
    }
}
