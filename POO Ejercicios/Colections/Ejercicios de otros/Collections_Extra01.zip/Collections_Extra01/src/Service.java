
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Service {

    Scanner read = new Scanner(System.in);
    private List<Integer> numbers = new ArrayList();

    public void numberRequest() {
        int n;

        System.out.println("...NUMBER REQUEST");
        System.out.println(">>>Enter the numbers");
        do {
            n = read.nextInt();
            numbers.add(n);
        } while (n != -99);
    }

    public void showCollection() {
        System.out.println("...SHOWING LIST");
//        for (Integer number : x) {
//            System.out.println(x);
//        }
        numbers.forEach((e)->System.out.println(e));
    }
}
